import pygame
import math

screenratio = 2.5
pygame.init()
screen = pygame.display.set_mode((int(1200/screenratio), int(700/screenratio)))
screen2 = pygame.display.set_mode((int(1200/screenratio), int(700/screenratio)))
screen3 = pygame.display.set_mode((int(1200/screenratio), int(700/screenratio)))
screen4 = pygame.display.set_mode((int(1200/screenratio), int(700/screenratio)))
screen5 = pygame.display.set_mode((int(1200/screenratio), int(700/screenratio)))

pygame.display.set_caption("Mortal Kombat")
icon = pygame.image.load('mk logo.png')
pygame.display.set_icon(icon)

background = pygame.image.load('mortal kombat background.png')
background = pygame.transform.scale(background, (int(1800/screenratio), int(700/screenratio)))
startscreen = pygame.image.load('mortal kombat start screen (1) (1).png')
startscreen = pygame.transform.scale(startscreen, (int(1200/screenratio), int(700/screenratio)))

scorpionjumping = pygame.image.load('scorpion jumping.png')
scorpionjumping = pygame.transform.scale(scorpionjumping, (int(128/screenratio), int(338/screenratio)))
scorpionjumping2 = pygame.image.load('scorpion jumping 2.png')
scorpionjumping2 = pygame.transform.scale(scorpionjumping2, (int(118/screenratio), int(150/screenratio)))
scorpionfalling = pygame.image.load('scorpion falling.png')
scorpionfalling = pygame.transform.scale(scorpionfalling, (int(220/screenratio), int(275/screenratio)))
scorpionthrowingsheet = pygame.image.load('scorpionthrows.png').convert_alpha()
scorpionidlesheet = pygame.image.load('scorpionidle.png').convert_alpha()
scorpionidlesheetflip = pygame.transform.flip(scorpionidlesheet, True, False)
scorpionwalkingsheet = pygame.image.load('scorpionwalking.png').convert_alpha()
scorpionwalkingsheetflip = pygame.transform.flip(scorpionwalkingsheet, True, False)
scorpionpunchingsheet = pygame.image.load('scorpionpunching.png').convert_alpha()
scorpionpunchingsheetflip = pygame.transform.flip(scorpionpunchingsheet, True, False)
punchingsound = pygame.mixer.Sound('punchingsound.wav')
scorpionthrowingsheetflip = pygame.transform.flip(scorpionthrowingsheet, True, False)
spearimg = pygame.image.load('spear.png')
spearimg = pygame.transform.scale(spearimg, (int(368/screenratio), int(43/screenratio)))
scorpionblocksheet = pygame.image.load('scorpionblocking.png').convert_alpha()
scorpionblocksheetflip = pygame.transform.flip(scorpionblocksheet, True, False)
scorpionfallsheet = pygame.image.load('scorpionfalls.png').convert_alpha()
scorpionfallsheetflip = pygame.transform.flip(scorpionfallsheet, True, False)
scorpionvictorysheet = pygame.image.load('scorpionwins.png').convert_alpha()
scorpionvictorysheetflip = pygame.transform.flip(scorpionvictorysheet, True, False)
scorpionwinsscreen = pygame.image.load('scorpion wins screen.png')
scorpionwinsscreen = pygame.transform.scale(scorpionwinsscreen, (int(1200/screenratio), int(700/screenratio)))

subzeroidlesheet = pygame.image.load('subzeroidle.png').convert_alpha()
subzerojumping = pygame.image.load('subzero jumping.png')
subzerojumping = pygame.transform.scale(subzerojumping, (int(140/screenratio), int(210/screenratio)))
subzerojumping2 = pygame.image.load('subzero jumping 2.png')
subzerojumping2 = pygame.transform.scale(subzerojumping2, (int(150/screenratio), int(220/screenratio)))
subzerofalling = pygame.image.load('subzerofalling.png')
subzerofalling = pygame.transform.scale(subzerofalling, (int(220/screenratio), int(275/screenratio)))
subzeroidlesheetflip = pygame.transform.flip(subzeroidlesheet, True, False)
subzerowalkingsheet = pygame.image.load('subzerowalking.png').convert_alpha()
subzerowalkingsheetflip = pygame.transform.flip(subzerowalkingsheet, True, False)
currentstatesz = 0
subzerokickingsheet = pygame.image.load('subzerokicking.png').convert_alpha()
subzerokickingsheetflip = pygame.transform.flip(subzerokickingsheet, True, False)
haskickedsz = False
currentstatekicking = 0
subzeroshootingsheet = pygame.image.load('subzeroshooting.png').convert_alpha()
subzeroshootingsheetflip = pygame.transform.flip(subzeroshootingsheet, True, False)
icesheet = pygame.image.load('ice.png')
icesheetflip = pygame.transform.flip(icesheet, True, False)
subzeroblockingsheet = pygame.image.load('subzeroblocking.png').convert_alpha()
subzeroblockingsheetflip = pygame.transform.flip(subzeroblockingsheet, True, False)
subzerofallsheet = pygame.image.load('subzerofalls.png').convert_alpha()
subzerofallsheetflip = pygame.transform.flip(subzerofallsheet, True, False)
subzerovictorysheet = pygame.image.load('subzerowins.png').convert_alpha()
subzerovictorysheetflip = pygame.transform.flip(subzerovictorysheet, True, False)
subzerowinsscreen = pygame.image.load('subzero wins screen.png')
subzerowinsscreen = pygame.transform.scale(subzerowinsscreen, (int(1200/screenratio), int(700/screenratio)))

currentstateblocking = 0
scorpionx = int(920/screenratio)
scorpiony = int(330/screenratio)
xchange = 0
ychange = 0
spearxchange = 0
scorpionorientation = 'left'
scorpionstate = 'ready'
scorpionhealth = int(300/screenratio)
scorpionmaxhealth = int(300/screenratio)
haspunched = False
currentstatepunching = 0
currentstate = 0
spearbarlength = int(0/screenratio)
spearbarmaxlength = int(210/screenratio)
spearbarx = int(1060/screenratio)
whichframe = 0
hasthrown = False
spearx = scorpionx
speary = (scorpiony + int(90/screenratio))
spearthrown = False
currentstatevictory = 0
scorpionhaslost = False
currentstatefalling = 0

currentstateblockingsz = 0
subzerox = int(150/screenratio)
subzeroy = int(370/screenratio)
xchangesz = 0
ychangesz = 0
szorientation = 'right'
szstate = 'ready'
subzerohealth = int(300/screenratio)
subzeromaxhealth = int(300/screenratio)
freezebarlength = int(0/screenratio)
freezebarmaxlength = int(210/screenratio)
freezebarx = int(150/screenratio)
whichframesz = 0
hasshot = False
icex = subzerox
icey = subzeroy
icexchange = 0
iceshot = False
currentstateice = 0
subzerohaslost = False
currentstatefallingsz = 0
currentstatevictorysz = 0

def healthbars(surface):
    pygame.draw.rect((surface), (0, 0, 0), pygame.Rect(int(100/screenratio), int(50/screenratio), subzeromaxhealth, int(30/screenratio)))
    pygame.draw.rect((surface), (0, 100, 0), pygame.Rect(int(100/screenratio), int(50/screenratio), subzerohealth, int(30/screenratio)))
    pygame.draw.rect((surface), (255, 255, 255), pygame.Rect(int(100/screenratio), int(50/screenratio), subzeromaxhealth, int(30/screenratio)), 2)
    pygame.draw.rect((surface), (0, 0, 0), pygame.Rect(int(800/screenratio), int(50/screenratio), scorpionmaxhealth, int(30/screenratio)))
    pygame.draw.rect((surface), (0, 100, 0), pygame.Rect(int(800/screenratio), int(50/screenratio), scorpionhealth, int(30/screenratio)))
    pygame.draw.rect((surface), (255,255,255), pygame.Rect(int(800/screenratio), int(50/screenratio), scorpionmaxhealth, int(30/screenratio)), 2)

def getimage(sheet, frame, width, height, scale):
    image = pygame.Surface((width, height)).convert_alpha()
    image.blit(sheet, (0, 0), (frame * width, 0, width, height))
    image = pygame.transform.scale(image, ((int(width * (scale * 2.5)/screenratio)), ((int(height * (scale * 2.5)/screenratio)))))
    image.set_colorkey((0,0,0))
    return image

punchsoundplaying = True

class scorpion():
    def scorpionhit():
        global scorpionx
        global szorientation
        global currentstatekicking
        global punchsoundplaying
        distance = math.sqrt((math.pow(scorpionx - subzerox, 2)) + (math.pow(scorpiony - subzeroy, 2)))
        distance2 = math.sqrt((math.pow(scorpionx - icex, 2)) + (math.pow(scorpiony - icey, 2)))
        if distance < int(200/screenratio) and szstate == 'kicking' and currentstatekicking > 5 or distance2 < int(100/screenratio) and szstate == 'shooting':
            if punchsoundplaying == True:
                punchingsound.play()
                punchsoundplaying = False
            if scorpionstate == 'ready' or scorpionstate == 'walking':
                if szorientation == 'left':
                    scorpionx -= 10
                    screen.blit(background, (int(-300/screenratio), 0))
                    healthbars(screen)
                    scorpion.spearbar(screen)
                    subzero.freezebar(screen)
                    screen.blit(scorpionfalling, (scorpionx, scorpiony))
                    subzero.szupdate(screen)
                    return True
                elif szorientation == 'right':
                    scorpionx += 10
                    screen.blit(background, (int(-300/screenratio), 0))
                    healthbars(screen)
                    scorpion.spearbar(screen)
                    subzero.freezebar(screen)
                    flip = pygame.transform.flip(scorpionfalling, True, False)
                    screen.blit(flip, (scorpionx, scorpiony))
                    subzero.szupdate(screen)
                    return True
                else: 
                    return False
            elif scorpionstate == 'blocking':
                if szorientation == 'left':
                    scorpionx -= 10
                    scorpion.scorpionblock()
                    return True
                elif szorientation == 'right':
                    scorpionx += 10
                    scorpion.scorpionblock()
                    return True
                else: 
                    return False

    def scorpionjump(scorpionjumping):
        global ychange
        if scorpionstate == 'jumping':
            if scorpionorientation == 'right':
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(scorpionjumping, (scorpionx, scorpiony))
                ychange = -10/screenratio
                subzero.szupdate(screen)
            elif scorpionorientation == 'left':
                flip = pygame.transform.flip(scorpionjumping, True, False)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(flip, (scorpionx, scorpiony))
                ychange = -10/screenratio
                subzero.szupdate(screen)
        elif scorpionstate == 'ready':
            pass

    def flip():
        global currentstate
        if scorpionorientation == 'right' and scorpionstate == 'ready':
            currentimage = getimage(scorpionidlesheet, int(currentstate), 82, 135, 0.75)
            screen.blit(currentimage, (scorpionx, (scorpiony + (int(43/screenratio)))))
            currentstate += 0.03
            if currentstate > 6:
                currentstate = 0
            else:
                pass
        elif scorpionorientation == 'left' and scorpionstate == 'ready':
            currentimage = getimage(scorpionidlesheetflip, (6 - int(currentstate)), 82, 135, 0.75)
            screen.blit(currentimage, (scorpionx, (scorpiony + (int(43/screenratio)))))
            currentstate += 0.03
            if currentstate > 6:
                currentstate = 0
            else:
                pass
        elif scorpionorientation == 'right' and scorpionstate == 'walking':
            currentimage = getimage(scorpionwalkingsheet, int(currentstate), 90, 129, 0.8)
            screen.blit(currentimage, (scorpionx, (scorpiony + int(45/screenratio))))
            currentstate += 0.05
            if currentstate > 8:
                currentstate = 0
            else:
                pass
        elif scorpionorientation == 'left' and scorpionstate == 'walking':
            currentimage = getimage(scorpionwalkingsheetflip, (8 - int(currentstate)), 90, 129, 0.80)
            screen.blit(currentimage, (scorpionx, (scorpiony + int(45/screenratio))))
            currentstate += 0.05
            if currentstate > 8:
                currentstate = 0
            else:
                pass

    def scorpionpunch():
        global currentstatepunching
        global haspunched
        global scorpionstate
        if scorpionstate == 'punching' and haspunched == False:
            if scorpionorientation == 'right':
                currentimage = getimage(scorpionpunchingsheet, int(currentstatepunching), 135, 153, 0.72)
                currentstatepunching += 0.1
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(currentimage, (scorpionx, (scorpiony + int(30/screenratio))))
                subzero.szupdate(screen)
                healthbars(screen)
                scorpion.spearbar(screen)
                subzero.freezebar(screen)
                if currentstatepunching > 5:
                    currentstatepunching = 0
                    haspunched = True
                    scorpionstate = 'ready'
                else:
                    pass
            elif scorpionorientation == 'left':
                currentstatepunching += 0.1
                currentimage = getimage(scorpionpunchingsheetflip, (4 - int(currentstatepunching)), 135, 153, 0.72)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(currentimage, ((scorpionx - int(100/screenratio)), (scorpiony + int(28/screenratio))))
                subzero.szupdate(screen)
                healthbars(screen)
                scorpion.spearbar(screen)
                subzero.freezebar(screen)
                if currentstatepunching > 5:
                    currentstatepunching = 0
                    haspunched = True
                    scorpionstate = 'ready'
                else:
                    pass

    def spearbar(surface):
        global spearbarlength
        global spearbarx
        global pausescreenrunning
        pygame.draw.rect((surface), (0,0,0), pygame.Rect(int(850/screenratio), int(100/screenratio), spearbarmaxlength, int(20/screenratio)))
        pygame.draw.rect((surface), (255, 0, 0), pygame.Rect(spearbarx, int(100/screenratio), int(spearbarlength), int(20/screenratio)))
        pygame.draw.rect((surface), (255, 255, 255), pygame.Rect(int(850/screenratio), int(100/screenratio), spearbarmaxlength, int(20/screenratio)), 2)
        if spearbarlength < int(210/screenratio) and pausescreenrunning == False:
            spearbarlength += 0.125/screenratio
            spearbarx -= 0.125/screenratio
        elif pausescreenrunning == True:
            spearbarlength = spearbarlength
        else:
            spearbarlength = int(210/screenratio)
            spearbarx = int(850/screenratio)

    def scorpionthrowing():
        global hasthrown
        global whichframe
        global scorpionstate
        global spearlength
        global spearbarx
        if scorpionstate == 'throwing' and hasthrown == False and spearbarlength == int(210/screenratio):
            if scorpionorientation == 'right':
                frame = getimage(scorpionthrowingsheet, int(whichframe), 120, 120, 0.9)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(frame, (scorpionx, (scorpiony + int(30/screenratio))))
                whichframe += 0.1
                subzero.szupdate(screen)
                if whichframe > 6:
                    whichframe = 0
                    hasthrown = True
                    scorpionstate = 'ready'
                else:
                    pass
            elif scorpionorientation == 'left':
                frame = getimage(scorpionthrowingsheetflip, (6.7 - int(whichframe + 1)), 120, 120, 0.9)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(frame, ((scorpionx - int(40/screenratio)), (scorpiony + int(30/screenratio))))
                whichframe += 0.1
                subzero.szupdate(screen)
                if whichframe > 6:
                    whichframe = 0
                    hasthrown = True
                    scorpionstate = 'ready'
                else:
                    pass

    def spear():
        global spearthrown
        global spearbarlength
        global spearbarx
        global spearx
        if scorpionstate == 'throwing' and spearbarlength == int(210/screenratio):
            if spearthrown == False:
                if scorpionorientation == 'right':
                    screen.blit(spearimg, ((spearx + int(100/screenratio)), speary))
                    if spearx == int(1000/screenratio):
                        spearthrown = True
                if scorpionorientation == 'left':
                    flipped = pygame.transform.flip(spearimg, True, False)
                    screen.blit(flipped, ((spearx - int(250/screenratio)), speary))
                    if spearx == int(0/screenratio):
                        spearthrown = True
                    else:
                        pass
        else:
            spearx = scorpionx

    def scorpionblock():
        global currentstateblocking
        if scorpionstate == 'blocking':
            if scorpionorientation == 'right':
                currentimage = getimage(scorpionblocksheet, int(currentstateblocking), 82, 143, 0.75)
                screen.blit(background, (int(-300/screenratio), 0))
                healthbars(screen)
                subzero.freezebar(screen)
                scorpion.spearbar(screen)
                if currentstateblocking < 2.1:
                    currentstateblocking += 0.1
                else:
                    currentstateblocking = 2
                screen.blit(currentimage, (scorpionx, 
                                   (scorpiony + int(30/screenratio))))
                subzero.szupdate(screen)
            elif scorpionorientation == 'left':
                currentimage = getimage(scorpionblocksheetflip, (2 - int(currentstateblocking)), 82, 143, 0.75)
                screen.blit(background, (int(-300/screenratio), 0))
                healthbars(screen)
                subzero.freezebar(screen)
                scorpion.spearbar(screen)
                if currentstateblocking < 2.1:
                    currentstateblocking += 0.1
                else:
                    currentstateblocking = 2
                screen.blit(currentimage, (scorpionx, (scorpiony + int(30/screenratio))))
                subzero.szupdate(screen)

    def scorpionupdate(surface):
        global ychange
        global currentstate
        global scorpionstate
        global scorpionorientation
        global haspunched
        global currentstatepunching
        global whichframe
        global hasthrown
        global spearbarx
        global spearx
        global spearbarlength
        global currentstateblocking
        global pausescreenrunning
        if scorpionorientation == 'right':
            if scorpionstate == 'ready':
                currentimage = getimage(scorpionidlesheet, int(currentstate), 82, 135, 0.75)
                surface.blit(currentimage, (scorpionx, (scorpiony + (int(43/screenratio)))))
                if pausescreenrunning == False:
                    currentstate += 0.01
                    if currentstate > 6:
                        currentstate = 0
                    else:
                        pass
            if scorpionstate == 'walking':
                currentimage = getimage(scorpionwalkingsheet, int(currentstate), 90, 129, 0.75)
                surface.blit(currentimage, (scorpionx, (scorpiony + int(50/screenratio))))
                if pausescreenrunning == False:
                    currentstate += 0.03
                    if currentstate > 8:
                        currentstate = 0
                    else:
                        pass
            if scorpionstate == 'throwing':
                scorpion.spear()
                frame = getimage(scorpionthrowingsheet, int(whichframe), 120, 120, 0.9)
                surface.blit(frame, (scorpionx, (scorpiony + int(30/screenratio))))
                if pausescreenrunning == False:
                    whichframe += 0.05
                    if whichframe > 6:
                        whichframe = 0
                        hasthrown = True
                        scorpionstate = 'ready'
                    else:
                        pass
                if pausescreenrunning == True:
                    hasthrown = True
                    hasthrown = False
                    spearx = scorpionx
                    spearbarx = int(1060/screenratio)
                    spearbarlength = 0
                    scorpionstate = 'ready'
            if scorpionstate == 'jumping':
                surface.blit(scorpionjumping, (scorpionx, scorpiony))
                ychange = -10/screenratio
            if scorpionstate == 'punching':
                currentimage = getimage(scorpionpunchingsheet, int(currentstatepunching), 135, 153, 0.72)
                surface.blit(currentimage, (scorpionx, (scorpiony + int(30/screenratio))))
                healthbars(surface)
                scorpion.spearbar(surface)
                subzero.freezebar(surface)
                if pausescreenrunning == False:
                    currentstatepunching += 0.03
                    if currentstatepunching > 5:
                        currentstatepunching = 0
                        scorpionstate = 'ready'
                        haspunched = True
                    else:
                        pass
                if pausescreenrunning == True:
                    currentstatepunching = 0
                    haspunched = True
                    haspunched = False
                    scorpionstate = 'ready'
            if scorpionstate == 'blocking':
                currentimage = getimage(scorpionblocksheet, int(currentstateblocking), 82, 143, 0.75)
                if pausescreenrunning == False:
                    if currentstateblocking < 2.1:
                        currentstateblocking += 0.05
                    else:
                        currentstateblocking = 2
                surface.blit(currentimage, (scorpionx, (scorpiony + int(30/screenratio))))
        elif scorpionorientation == 'left':
            if scorpionstate == 'ready':
                currentimage = getimage(scorpionidlesheetflip, (6 - int(currentstate)), 82, 135, 0.75)
                surface.blit(currentimage, (scorpionx, (scorpiony + (int(43/screenratio)))))
                if pausescreenrunning == False:
                    currentstate += 0.01
                    if currentstate > 6:
                        currentstate = 0
                    else:
                        pass
            if scorpionstate == 'walking':
                currentimage = getimage(scorpionwalkingsheetflip, (8 - int(currentstate)), 90, 129, 0.75)
                surface.blit(currentimage, (scorpionx, (scorpiony + int(50/screenratio))))
                if pausescreenrunning == False:
                    currentstate += 0.03
                    if currentstate > 8:
                        currentstate = 0
                    else:
                        pass
            if scorpionstate == 'throwing':
                scorpion.spear()
                frame = getimage(scorpionthrowingsheetflip, (6.7 - int(whichframe + 1)), 120, 120, 0.9)
                surface.blit(frame, ((scorpionx - int(40/screenratio)), (scorpiony + int(30/screenratio))))
                if pausescreenrunning == False:
                    whichframe += 0.05
                    if whichframe > 6:
                        whichframe = 0
                        hasthrown = True
                        scorpionstate = 'ready'
                    else:
                        pass
                if pausescreenrunning == True:
                    hasthrown = True
                    hasthrown = False
                    spearx = scorpionx
                    spearbarx = int(1060/screenratio)
                    spearbarlength = 0
                    scorpionstate = 'ready'
            if scorpionstate == 'punching':
                currentimage = getimage(scorpionpunchingsheetflip, (4 - int(currentstatepunching)), 135, 153, 0.72)
                surface.blit(currentimage, ((scorpionx - int(100/screenratio)), (scorpiony + int(28/screenratio))))
                healthbars(surface)
                scorpion.spearbar(surface)
                subzero.freezebar(surface)
                if pausescreenrunning == False:
                    currentstatepunching += 0.03
                    if currentstatepunching > 5:
                        currentstatepunching = 0
                        haspunched = True
                        scorpionstate = 'ready'
                    else:
                        pass
                if pausescreenrunning == True:
                    currentstatepunching = 0
                    haspunched = True
                    haspunched = False
                    scorpionstate = 'ready'
            if scorpionstate == 'blocking':
                currentimage = getimage(scorpionblocksheetflip, (2 - int(currentstateblocking)), 82, 143, 0.75)
                if currentstateblocking < 2.1 and pausescreenrunning == False:
                    currentstateblocking += 0.05
                else:
                    currentstateblocking = 2
                surface.blit(currentimage, (scorpionx, (scorpiony + int(30/screenratio))))
            if scorpionstate == 'jumping':
                flipped = pygame.transform.flip(scorpionjumping, True, False)
                surface.blit(flipped, (scorpionx, scorpiony))
                ychange = -10/screenratio

class subzero():
    def szupdate(surface):
        global ychangesz
        global currentstatesz
        global currentstatekicking
        global hasshot
        global whichframesz
        global szstate
        global freezebarlength
        global freezebarx
        global icex
        global haskickedsz
        global currentstateblockingsz
        global pausescreenrunning
        if szorientation == 'right':
            if szstate == 'ready':
                currentimage = getimage(subzeroidlesheet, int(currentstatesz), 74, 135, 0.75)
                surface.blit(currentimage, (subzerox, subzeroy))
                if pausescreenrunning == False:
                    currentstatesz += 0.03
                    if currentstatesz > 11:
                        currentstatesz = 0
                    else:
                        pass
            elif szstate == 'kicking':
                if szstate == 'kicking' and haskickedsz == False:
                    currentimage = getimage(subzerokickingsheet, int(currentstatekicking), 149, 143, 0.75)
                    if pausescreenrunning == False:
                        currentstatekicking += 0.05
                    else:
                        currentstatekicking = 0
                        haskickedsz = True
                        haskickedsz = False
                        szstate = 'ready'
                    surface.blit(currentimage, (subzerox, subzeroy))
                    healthbars(surface)
                    scorpion.spearbar(surface)
                    subzero.freezebar(surface)
                    if currentstatekicking > 8.8:
                        currentstatekicking = 0
                        haskickedsz = True
                        szstate = 'ready'
                    else:
                        pass
            elif szstate == 'walking':
                currentimage = getimage(subzerowalkingsheet, int(currentstatesz), 93, 138, 0.75)
                surface.blit(currentimage, (subzerox, (subzeroy)))
                if pausescreenrunning == False:
                    currentstatesz += 0.03
                    if currentstatesz > 8:
                        currentstatesz = 0
                    else:
                        pass
            elif szstate == 'shooting':
                subzero.ice()
                if hasshot == False and freezebarlength == int(210/screenratio):
                    frame = getimage(subzeroshootingsheet, int(whichframesz), 100, 138, 0.75)
                    surface.blit(frame, (subzerox, subzeroy))
                    if pausescreenrunning == False:
                        whichframesz += 0.03
                        if whichframesz > 5:
                            whichframesz = 0
                            hasshot = True
                            szstate = 'ready'
                    else:
                        whichframesz = 0
                        icex = subzerox
                        freezebarlength = 0
                        hasshot = True
                        hasshot = False
                        szstate = 'ready'
            elif szstate == 'blocking':
                currentimage = getimage(subzeroblockingsheet, int(currentstateblockingsz), 75, 142, 0.75)
                surface.blit(currentimage, (subzerox, subzeroy))
                if currentstateblockingsz < 2 and pausescreenrunning == False:
                    currentstateblockingsz += 0.05
                else:
                    currentstateblockingsz = 2
            elif szstate == 'jumping':
                surface.blit(subzerojumping, (subzerox, subzeroy))
                ychangesz = -10/screenratio
        elif szorientation == 'left':
            if szstate == 'ready':
                currentimage = getimage(subzeroidlesheetflip, (11 - int(currentstatesz)), 74, 135, 0.75)
                surface.blit(currentimage, (subzerox, (subzeroy)))
                if pausescreenrunning == False:
                    currentstatesz += 0.03
                    if currentstatesz > 11:
                        currentstatesz = 0
                    else:
                        pass
            elif szstate == 'walking':
                currentimage = getimage(subzerowalkingsheetflip, (8 - int(currentstatesz)), 93, 138, 0.75)
                surface.blit(currentimage, (subzerox, (subzeroy)))
                if pausescreenrunning == False:
                    currentstatesz += 0.03
                    if currentstatesz > 8:
                        currentstatesz = 0
                    else:
                        pass
            elif szstate == 'kicking':
                if pausescreenrunning == False:
                    currentstatekicking += 0.05
                else:
                    currentstatekicking = 0
                    haskickedsz = True
                    haskickedsz = False
                    szstate = 'ready'
                currentimage = getimage(subzerokickingsheetflip, (8 - int(currentstatekicking)), 151, 143, 0.75)
                surface.blit(currentimage, ((subzerox - int(120/screenratio)), subzeroy))
                healthbars(surface)
                scorpion.spearbar(surface)
                subzero.freezebar(surface)
                if currentstatekicking > 8.8:
                    currentstatekicking = 0
                    haskickedsz = True
                    szstate = 'ready'
                else:
                    pass
            elif szstate == 'blocking':
                currentimage = getimage(subzeroblockingsheetflip, (2 - int(currentstateblockingsz)), 75, 142, 0.75)
                surface.blit(currentimage, (subzerox, subzeroy))
                if currentstateblockingsz < 2 and pausescreenrunning == False:
                    currentstateblockingsz += 0.05
                else:
                    currentstateblockingsz = 2
                scorpion.scorpionupdate(screen)
            elif szstate == 'jumping':
                flipsz = pygame.transform.flip(subzerojumping, True, False)
                surface.blit(flipsz, (subzerox, subzeroy))
                ychangesz = -10/screenratio
            elif szstate == 'shooting':
                subzero.ice()
                frame = getimage(subzeroshootingsheetflip, (4 - int(whichframesz)), 102, 138, 0.75)
                surface.blit(frame, ((subzerox, subzeroy)))
                if pausescreenrunning == False:
                    whichframesz += 0.03
                    if whichframesz > 5:
                        whichframesz = 0
                        hasshot = True
                        szstate = 'ready'
                else:
                    whichframesz = 0
                    icex = subzerox
                    freezebarlength = 0
                    hasshot = True
                    hasshot = False
                    szstate = 'ready'

    def szjump(subzerojumping):
        global ychangesz
        if szstate == 'jumping':
            if szorientation == 'right':
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(subzerojumping, (subzerox, subzeroy))
                ychangesz = -10/screenratio
                scorpion.scorpionupdate(screen)
            elif szorientation == 'left':
                flipsz = pygame.transform.flip(subzerojumping, True, False)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(flipsz, (subzerox, subzeroy))
                ychangesz = -10/screenratio
                scorpion.scorpionupdate(screen)
        elif szstate == 'ready':
            pass

    def flipszfunc():
        global currentstatesz
        if szorientation == 'right' and szstate == 'ready':
            currentimage = getimage(subzeroidlesheet, int(currentstatesz), 74, 135, 0.75)
            screen.blit(currentimage, (subzerox, subzeroy))
            currentstatesz += 0.06
            if currentstatesz > 11:
                currentstatesz = 0
            else:
                pass
        elif szorientation == 'left' and szstate == 'ready':
            currentimage = getimage(subzeroidlesheetflip, (11 - int(currentstatesz)), 74, 135, 0.75)
            screen.blit(currentimage, (subzerox, (subzeroy)))
            currentstatesz += 0.06
            if currentstatesz > 11:
                currentstatesz = 0
            else:
                pass
        elif szorientation == 'right' and szstate == 'walking':
            currentimage = getimage(subzerowalkingsheet, int(currentstatesz), 93, 138, 0.75)
            screen.blit(currentimage, (subzerox, (subzeroy)))
            currentstatesz += 0.05
            if currentstatesz > 8:
                currentstatesz = 0
            else:
                pass
        elif szorientation == 'left' and szstate == 'walking':
            currentimage = getimage(subzerowalkingsheetflip, (8 - int(currentstatesz)), 93, 138, 0.75)
            screen.blit(currentimage, (subzerox, (subzeroy)))
            currentstatesz += 0.05
            if currentstatesz > 8:
                currentstatesz = 0
            else:
                pass

    def szkicking():
        global currentstatekicking
        global haskickedsz
        global szstate
        if szstate == 'kicking' and haskickedsz == False:
            if szorientation == 'right':
                currentimage = getimage(subzerokickingsheet, int(currentstatekicking), 149, 143, 0.75)
                currentstatekicking += 0.1
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(currentimage, (subzerox, subzeroy))
                scorpion.scorpionupdate(screen)
                healthbars(screen)
                scorpion.spearbar(screen)
                subzero.freezebar(screen)
                if currentstatekicking > 8:
                    currentstatekicking = 0
                    haskickedsz = True
                    szstate = 'ready'
                else:
                    pass
            elif szorientation == 'left':
                currentstatekicking += 0.1
                currentimage = getimage(subzerokickingsheetflip, (7 - int(currentstatekicking)), 151, 143, 0.75)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(currentimage, ((subzerox - int(120/screenratio)), subzeroy))
                scorpion.scorpionupdate(screen)
                healthbars(screen)
                scorpion.spearbar(screen)
                subzero.freezebar(screen)
                if currentstatekicking > 8:
                    currentstatekicking = 0
                    haskickedsz = True
                    szstate = 'ready'
                else:
                    pass

    def subzerohit():
        global subzerox
        global scorpionorientation
        global currentstatepunching
        distance = math.sqrt((math.pow(subzerox - scorpionx, 2)) + (math.pow(subzeroy - scorpiony, 2)))
        distance2 = math.sqrt((math.pow(subzerox - spearx, 2)) + (math.pow(subzeroy - speary, 2)))
        if distance < int(180/screenratio) and scorpionstate == 'punching' and currentstatepunching > 3 or distance2 < int(250/screenratio) and scorpionstate == 'throwing':
            punchingsound.play()
            if szstate == 'ready' or szstate == 'walking':
                if scorpionorientation == 'left':
                    subzerox -= 10
                    screen.blit(background, (int(-300/screenratio), 0))
                    screen.blit(subzerofalling, (subzerox, subzeroy))
                    scorpion.scorpionupdate(screen)
                    healthbars(screen)
                    scorpion.spearbar(screen)
                    subzero.freezebar(screen)
                    return True
                elif scorpionorientation == 'right':
                    subzerox += 10
                    screen.blit(background, (int(-300/screenratio), 0))
                    flip = pygame.transform.flip(subzerofalling, True, False)
                    screen.blit(flip, (subzerox, subzeroy))
                    scorpion.scorpionupdate(screen)
                    healthbars(screen)
                    scorpion.spearbar(screen)
                    subzero.freezebar(screen)
                    return True
                else:
                    return False
            elif szstate == 'blocking':
                if scorpionorientation == 'left':
                    subzerox -= 10
                    screen.blit(background, (int(-300/screenratio), 0))
                    subzero.szblock()
                    return True
                elif scorpionorientation == 'right':
                    subzerox += 10
                    screen.blit(background, (int(-300/screenratio), 0))
                    subzero.szblock()
                    return True
            else:
                return False

    def freezebar(surface):
        global freezebarlength
        global freezebarx
        global pausescreenrunning
        pygame.draw.rect((surface), (0, 0, 0), pygame.Rect(int(150/screenratio), int(100/screenratio), freezebarmaxlength, int(20/screenratio)))
        pygame.draw.rect((surface), (255, 0, 0), pygame.Rect(freezebarx, int(100/screenratio), int(freezebarlength), int(20/screenratio)))
        pygame.draw.rect((surface), (255, 255, 255), pygame.Rect(int(150/screenratio), int(100/screenratio), freezebarmaxlength, int(20/screenratio)), 2)
        if freezebarlength < int(210/screenratio) and pausescreenrunning == False:
            freezebarlength += 0.125/screenratio
        elif pausescreenrunning == True:
            freezebarlength = freezebarlength
        else:
            freezebarlength = int(210/screenratio)

    def subzeroshooting():
        global hasshot
        global whichframesz
        global szstate
        global freezebarlength
        global freezebarx
        if szstate == 'shooting' and hasshot == False and freezebarlength == int(210/screenratio):
            if szorientation == 'right':
                frame = getimage(subzeroshootingsheet, int(whichframesz), 100, 138, 0.75)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(frame, (subzerox, subzeroy))
                scorpion.scorpionupdate(screen)
                whichframesz += 0.08
                if whichframesz > 5:
                    whichframesz = 0
                    hasshot = True
                    szstate = 'ready'
                else:
                    pass
            elif szorientation == 'left':
                frame = getimage(subzeroshootingsheetflip, (4 - int(whichframesz)), 102, 138, 0.75)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(frame, ((subzerox, subzeroy)))
                scorpion.scorpionupdate(screen)
                whichframesz += 0.08
                if whichframesz > 5:
                    whichframesz = 0
                    hasshot = True
                    szstate = 'ready'
                else:
                    pass

    def ice():
        global iceshot
        global freezebarlength
        global freezebarx
        global icex
        global currentstateice
        if szstate == 'shooting' and freezebarlength == int(210/screenratio):
            if iceshot == False:
                if szorientation == 'right':
                    currentimage = getimage(icesheet, int(currentstateice), 88, 63, 0.7)
                    if currentstateice < 5:
                        currentstateice += 0.03
                    else:
                        currentstateice = 0 
                    screen.blit(currentimage, (icex, icey))
                    if icex == int(1000/screenratio):
                        iceshot = True
                if szorientation == 'left':
                    currentimage = getimage(icesheetflip, (4 - int(currentstateice)), 88, 63, 0.7)
                    if currentstateice < 5:
                        currentstateice += 0.03
                    else:
                        currentstateice = 0 
                    screen.blit(currentimage, (icex, icey))
                    if icex == int(0/screenratio):
                        iceshot = True
                    else:
                        pass
        else:
            icex = subzerox

    def szblock():
        global currentstateblockingsz
        if szstate == 'blocking':
            if szorientation == 'right':
                currentimage = getimage(subzeroblockingsheet, int(currentstateblockingsz), 75, 142, 0.75)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(currentimage, (subzerox, subzeroy))
                healthbars(screen)
                subzero.freezebar(screen)
                scorpion.spearbar(screen)
                if currentstateblockingsz < 2:
                    currentstateblockingsz += 0.1
                else:
                    currentstateblockingsz = 2
                scorpion.scorpionupdate(screen)
            elif szorientation == 'left':
                currentimage = getimage(subzeroblockingsheetflip, (2 - int(currentstateblockingsz)), 75, 142, 0.75)
                screen.blit(background, (int(-300/screenratio), 0))
                screen.blit(currentimage, (subzerox, subzeroy))
                healthbars(screen)
                subzero.freezebar(screen)
                scorpion.spearbar(screen)
                if currentstateblockingsz < 2:
                    currentstateblockingsz += 0.1
                else:
                    currentstateblockingsz = 2
                scorpion.scorpionupdate(screen)

clock = pygame.time.Clock()
countdownrunning = False
count3 = pygame.image.load('3.png')
count3 = pygame.transform.scale(count3, ((int(1200/screenratio), int(700/screenratio))))
count2 = pygame.image.load('2.png')
count2 = pygame.transform.scale(count2, ((int(1200/screenratio), int(700/screenratio))))
count1 = pygame.image.load('1.png')
count1 = pygame.transform.scale(count1, ((int(1200/screenratio), int(700/screenratio))))
countfight = pygame.image.load('fight.png')
countfight = pygame.transform.scale(countfight, ((int(1200/screenratio), int(700/screenratio))))
optionsscreen = pygame.image.load('options menu (1).png')
optionsscreen = pygame.transform.scale(optionsscreen, (int(1200/screenratio), int(700/screenratio)))
pausescreen = pygame.image.load('pause screen.png')
pausescreen = pygame.transform.scale(pausescreen, ((int(1200/screenratio), int(700/screenratio))))
menurunning = True
optionsrunning = False
pausescreenrunning = False

class menu():
    def mainmenu(screen2):
        global menurunning
        global optionsrunning
        global countdownrunning
        global freezebarlength
        global spearbarlength
        global spearbarx
        while menurunning:
            freezebarlength = 0
            spearbarlength = 0
            spearbarx = int(1060/screenratio)
            screen2.fill((0,0,0))
            screen2.blit(startscreen, (0,0))
            mx, my = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1 and mx >= int(370/screenratio) and mx <= int(533/screenratio) and my >= int(563/screenratio) and my <= int(588/screenratio):
                        countdownrunning = True
                        menurunning = False
                    elif event.button == 1 and mx >= int(605/screenratio) and mx <= int(840/screenratio) and my >= int(563/screenratio) and my <= int(588/screenratio):
                        optionsrunning = True
                        menurunning = False
            pygame.display.update()

    def countdown(screen4):
        global countdownrunning
        global currentstate
        global currentstatesz
        global spearbarlength
        global freezebarlength
        index = 0
        while countdownrunning:
            screen4.fill((0,0,0))
            screen4.blit(background, (int(-300/screenratio),0))
            healthbars(screen)
            scorpion.spearbar(screen)
            subzero.freezebar(screen)
            spearbarlength = 0
            freezebarlength = 0
            currentimage = getimage(scorpionidlesheetflip, (6 - int(currentstate)), 82, 135, 0.75)
            screen4.blit(currentimage, (scorpionx, (scorpiony + (int(43/screenratio)))))
            currentstate += 0.01
            if currentstate > 6:
                currentstate = 0
            else:
                pass
            currentimagesz = getimage(subzeroidlesheet, int(currentstatesz), 75, 135, 0.75)
            screen4.blit(currentimagesz, (subzerox, subzeroy))
            currentstatesz += 0.03
            if currentstatesz > 11:
                currentstatesz = 0
            else:
                pass  
            imagelist = [count3, count2, count1, countfight, countfight]
            image  = imagelist[index]
            screen4.blit(image, (0, 0))
            if index < 4:
                index += 1
            else:
                countdownrunning = False
            clock.tick(1)
            pygame.display.update()

    def optionsmenu(screen3):
        global optionsrunning
        global menurunning
        while optionsrunning:
            screen3.fill((0,0,0))
            screen3.blit(optionsscreen, (0, 0))
            mx, my = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1 and mx >= int(1040/screenratio) and mx <= int(1180/screenratio) and my >= int(43/screenratio) and my <= int(130/screenratio):
                        menurunning = True
                        optionsrunning = False
            pygame.display.update()

    def pausescreen():
        global pausescreenrunning
        global running
        global menurunning
        while pausescreenrunning:
            screen4.fill((0,0,0))
            screen4.blit(background, (int(-300/screenratio), 0))
            subzero.szupdate(screen4)
            scorpion.scorpionupdate(screen4)
            healthbars(screen4)
            scorpion.spearbar(screen4)
            subzero.freezebar(screen4)
            screen4.blit(pausescreen, (0,0))
            mx, my = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1 and mx >= int(400/screenratio) and mx <= int(765/screenratio) and my >= int(320/screenratio) and my <= int(358/screenratio):
                        pausescreenrunning = False
                    elif event.button == 1 and mx >= int(435/screenratio) and mx <= int(710/screenratio) and my >= int(390/screenratio) and my <= int(413/screenratio):
                        pausescreenrunning = False
                        menurunning = True
            pygame.display.update()


class endscreens():
    def subzeroloses():
        global subzerohaslost
        global menurunning
        global currentstatefallingsz
        global currentstate
        global currentstatevictory
        global subzerox
        global subzeroy
        global scorpionx
        global scorpiony
        global scorpionhealth
        global scorpionmaxhealth
        global subzerohealth
        global subzeromaxhealth
        global freezebarlength
        global spearbarlength
        global spearbarx
        while subzerohaslost:
            screen5.fill((0,0,0))
            screen5.blit(background, (int(-300/screenratio), 0))
            freezebarlength = 0
            spearbarlength = 0
            spearbarx = int(1060/screenratio)
            healthbars(screen5)
            subzero.freezebar(screen5)
            scorpion.spearbar(screen5)
            freezebarlength = 0
            spearbarlength = 0
            spearbarx = int(1060/screenratio)
            if scorpionorientation == 'left':
                currentimage = getimage(subzerofallsheet, int(currentstatefallingsz), 145, 161, 0.75)
                currentimagefirst = getimage(scorpionidlesheetflip, int(6 - currentstate), 82, 135, 0.75)
                currentimagevictory = getimage(scorpionvictorysheet, int(currentstatevictory), 76, 162, 0.75)
                screen5.blit(currentimage, (subzerox, subzeroy))
                if currentstatefallingsz < 4:
                    currentstatefallingsz += 0.03
                    screen5.blit(currentimagefirst, (scorpionx, (scorpiony + (int(43/screenratio)))))
                else:
                    currentstatefallingsz = 4
                    screen5.blit(currentimagevictory, (scorpionx, scorpiony))
                    if currentstatevictory < 3:
                        currentstatevictory += 0.02
                    else:
                        currentstatevictory = 3
                        screen5.blit(scorpionwinsscreen, (0,0))
                        mx, my = pygame.mouse.get_pos()
                        for event in pygame.event.get():
                            if event.type == pygame.MOUSEBUTTONDOWN:
                                if event.button == 1 and mx >= int(443/screenratio) and mx <= int(783/screenratio) and my >= int(423/screenratio) and my <= int(460/screenratio):
                                    menurunning = True
                                    scorpionhealth = scorpionmaxhealth
                                    subzerohealth = subzeromaxhealth
                                    scorpionx = int(920/screenratio)
                                    scorpiony = int(330/screenratio)
                                    subzerox = int(150/screenratio)
                                    subzeroy = int(370/screenratio)
                                    freezebarlength = 0
                                    spearbarlength = 0
                                    spearbarx = int(1060/screenratio)
                                    currentstatevictory = 0
                                    currentstatefallingsz = 0
                                    currentstate = 0
                                    subzerohaslost = False
            elif scorpionorientation == 'right':
                currentimageflip = getimage(subzerofallsheetflip, int(4 - currentstatefallingsz), 145, 161, 0.75)
                currentimagefirstflip = getimage(scorpionidlesheet, int(currentstate), 82, 135, 0.75)
                currentimagevictoryflip = getimage(scorpionvictorysheetflip, int(3 - currentstatevictory), 76, 162, 0.75)
                screen5.blit(currentimageflip, (subzerox, subzeroy))
                if currentstatefallingsz < 4:
                    currentstatefallingsz += 0.03
                    screen5.blit(currentimagefirstflip, (scorpionx, (scorpiony + (int(43/screenratio)))))
                else:
                    currentstatefallingsz = 4
                    screen5.blit(currentimagevictoryflip, (scorpionx, scorpiony))
                    if currentstatevictory < 3:
                        currentstatevictory += 0.02
                    else:
                        currentstatevictory = 3
                        screen5.blit(scorpionwinsscreen, (0,0))
                        mx, my = pygame.mouse.get_pos()
                        for event in pygame.event.get():
                            if event.type == pygame.MOUSEBUTTONDOWN:
                                if event.button == 1 and mx >= int(443/screenratio) and mx <= int(783/screenratio) and my >= int(423/screenratio) and my <= int(460/screenratio):
                                    menurunning = True
                                    scorpionhealth = scorpionmaxhealth
                                    subzerohealth = subzeromaxhealth
                                    scorpionx = int(920/screenratio)
                                    scorpiony = int(330/screenratio)
                                    subzerox = int(150/screenratio)
                                    subzeroy = int(370/screenratio)
                                    freezebarlength = 0
                                    spearbarlength = 0
                                    spearbarx = int(1060/screenratio)
                                    currentstatevictory = 0
                                    currentstatefallingsz = 0
                                    currentstate = 0
                                    subzerohaslost = False
            pygame.display.update()

    def scorpionloses():
        global scorpionhaslost
        global menurunning
        global currentstatefalling
        global currentstatesz
        global currentstatevictorysz
        global subzerox
        global subzeroy
        global scorpionx
        global scorpiony
        global scorpionhealth
        global scorpionmaxhealth
        global subzerohealth
        global subzeromaxhealth
        global freezebarlength
        global spearbarlength
        global spearbarx
        while scorpionhaslost:
            screen5.fill((0,0,0))
            screen5.blit(background, (int(-300/screenratio), 0))
            freezebarlength = 0
            spearbarlength = 0
            spearbarx = int(1060/screenratio)
            healthbars(screen5)
            subzero.freezebar(screen5)
            scorpion.spearbar(screen5)
            freezebarlength = 0
            spearbarlength = 0
            spearbarx = int(1060/screenratio)
            if szorientation == 'left':
                currentimage = getimage(scorpionfallsheet, int(currentstatefalling), 145, 161, 0.75)
                currentimagefirst = getimage(subzeroidlesheetflip, (11 - int(currentstatesz)), 74, 135, 0.75)
                currentimagevictory = getimage(subzerovictorysheet, int(currentstatevictorysz), 83, 162, 0.75)
                screen5.blit(currentimage, (scorpionx, scorpiony))
                if currentstatefalling < 4:
                    currentstatefalling += 0.03
                    screen5.blit(currentimagefirst, (subzerox, subzeroy))
                else:
                    currentstatefalling = 4
                    screen5.blit(currentimagevictory, (subzerox, int(subzeroy - 45/screenratio)))
                    if currentstatevictorysz < 3:
                        currentstatevictorysz += 0.02
                    else:
                        currentstatevictorysz = 3
                        screen5.blit(subzerowinsscreen, (0,0))
                        mx, my = pygame.mouse.get_pos()
                        for event in pygame.event.get():
                            if event.type == pygame.MOUSEBUTTONDOWN:
                                if event.button == 1 and mx >= int(443/screenratio) and mx <= int(783/screenratio) and my >= int(423/screenratio) and my <= int(460/screenratio):
                                    menurunning = True
                                    scorpionhealth = scorpionmaxhealth
                                    subzerohealth = subzeromaxhealth
                                    scorpionx = int(920/screenratio)
                                    scorpiony = int(330/screenratio)
                                    subzerox = int(150/screenratio)
                                    subzeroy = int(370/screenratio)
                                    freezebarlength = 0
                                    spearbarlength = 0
                                    spearbarx = int(1060/screenratio)
                                    currentstatevictorysz = 0
                                    currentstatefalling = 0
                                    currentstatesz = 0
                                    scorpionhaslost = False
            elif szorientation == 'right':
                currentimageflip = getimage(scorpionfallsheetflip, int(4 - currentstatefalling), 145, 161, 0.75)
                currentimagefirstflip = getimage(subzeroidlesheet, int(currentstatesz), 74, 135, 0.75)
                currentimagevictoryflip = getimage(subzerovictorysheetflip, int(3 - currentstatevictorysz), 83, 162, 0.75)
                screen5.blit(currentimageflip, (scorpionx, scorpiony))
                if currentstatefalling < 4:
                    currentstatefalling += 0.03
                    screen5.blit(currentimagefirstflip, (subzerox, subzeroy))
                else:
                    currentstatefalling = 4
                    screen5.blit(currentimagevictoryflip, (subzerox, int(subzeroy - 45/screenratio)))
                    if currentstatevictorysz < 3:
                        currentstatevictorysz += 0.02
                    else:
                        currentstatevictorysz = 3
                        screen5.blit(subzerowinsscreen, (0,0))
                        mx, my = pygame.mouse.get_pos()
                        for event in pygame.event.get():
                            if event.type == pygame.MOUSEBUTTONDOWN:
                                if event.button == 1 and mx >= int(443/screenratio) and mx <= int(783/screenratio) and my >= int(423/screenratio) and my <= int(460/screenratio):
                                    menurunning = True
                                    scorpionhealth = scorpionmaxhealth
                                    subzerohealth = subzeromaxhealth
                                    scorpionx = int(920/screenratio)
                                    scorpiony = int(330/screenratio)
                                    subzerox = int(150/screenratio)
                                    subzeroy = int(370/screenratio)
                                    freezebarlength = 0
                                    spearbarlength = 0
                                    spearbarx = int(1060/screenratio)
                                    currentstatevictorysz = 0
                                    currentstatefalling = 0
                                    currentstatesz = 0
                                    scorpionhaslost = False
            pygame.display.update()

running = True
while running:
    screen.fill((0, 0, 0))
    screen.blit(background, (int(-300/screenratio), 0))

    menu.mainmenu(screen2)
    menu.optionsmenu(screen3)
    menu.countdown(screen4)
    menu.pausescreen()

    endscreens.subzeroloses()
    endscreens.scorpionloses()

    subzero.flipszfunc()
    subzero.szkicking()
    subzero.szblock()
    subzero.szjump(subzerojumping)
    subzero.subzeroshooting()
    subzero.ice()

    scorpion.flip()
    scorpion.scorpionpunch()
    scorpion.scorpionblock()
    scorpion.scorpionjump(scorpionjumping)  
    scorpion.scorpionthrowing()
    scorpion.spear()

    if scorpiony <= int(180/screenratio):
        screen.blit(background, (int(-300/screenratio), 0))
        if scorpionorientation == 'right':
            screen.blit(scorpionjumping2, (scorpionx, scorpiony + int(30/screenratio)))
            subzero.szupdate(screen)
        elif scorpionorientation == 'left':
            flip2 = pygame.transform.flip(scorpionjumping2, True, False)
            screen.blit(flip2, (scorpionx, scorpiony + int(30/screenratio)))
            subzero.szupdate(screen)
    if scorpiony <= 120/screenratio:
        ychange = 10/screenratio
        scorpionstate = 'ready'
    elif scorpiony >= int(330/screenratio):
        ychange = 0
        scorpiony = int(330/screenratio)
            
    if subzeroy <= int(190/screenratio):
        screen.blit(background, (int(-300/screenratio), 0))
        if szorientation == 'right':
            screen.blit(subzerojumping2, (subzerox, subzeroy - int(30/screenratio)))
            scorpion.scorpionupdate(screen)
        elif szorientation == 'left':
            flip2sz = pygame.transform.flip(subzerojumping2, True, False)
            screen.blit(flip2sz, (subzerox, subzeroy - int(30/screenratio)))
            scorpion.scorpionupdate(screen)
    if subzeroy <= int(140/screenratio):
        ychangesz = 7.5/screenratio
        szstate = 'ready'
    elif subzeroy >= int(370/screenratio):
        ychangesz = 0
        subzeroy = int(370/screenratio)

    healthbars(screen)
    scorpion.spearbar(screen)
    subzero.freezebar(screen)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE and menurunning == False and optionsrunning == False and countdownrunning == False:
                pausescreenrunning = True
            if event.key == pygame.K_LEFT and scorpionstate != 'punching' and scorpionstate != 'blocking':
                scorpionorientation = 'left'
                scorpionstate = 'walking'
                scorpion.flip()
                xchange = -1.5/screenratio
            if event.key == pygame.K_RIGHT and scorpionstate != 'punching' and scorpionstate != 'blocking':
                scorpionorientation = 'right'
                scorpionstate = 'walking'
                scorpion.flip()
                xchange = 1.5/screenratio
            if event.key == pygame.K_UP and scorpiony == int(330/screenratio):
                scorpionstate = 'jumping'
                scorpiony += -5/screenratio
            if event.key == pygame.K_RCTRL and scorpionstate != 'walking':
                scorpionstate = 'punching'
            if event.key == pygame.K_m and scorpionstate != 'walking' and spearbarlength == spearbarmaxlength:
                scorpionstate = 'throwing'
                if scorpionorientation == 'right':
                    spearxchange = 6/screenratio
                elif scorpionorientation == 'left':
                    spearxchange = -6/screenratio
            if event.key == pygame.K_z and szstate != 'walking' and freezebarlength == freezebarmaxlength:
                szstate = 'shooting'
                if szorientation == 'left':
                    icexchange = -6/screenratio
                elif szorientation == 'right':
                    icexchange = 6/screenratio
            if event.key == pygame.K_RSHIFT and scorpionstate != 'walking':
                scorpionstate = 'blocking'
            if event.key == pygame.K_a and szstate != 'kicking' and szstate != 'blocking':
                szorientation = 'left'
                szstate = 'walking'
                subzero.flipszfunc()
                xchangesz = -1.5/screenratio
            if event.key == pygame.K_d and szstate != 'kicking' and szstate != 'blocking':
                szorientation = 'right'
                szstate = 'walking'
                subzero.flipszfunc()
                xchangesz = 1.5/screenratio
            if event.key == pygame.K_w and subzeroy == int(370/screenratio):
                szstate = 'jumping'
                subzeroy += -5/screenratio
            if event.key == pygame.K_LCTRL and szstate != 'walking':
                szstate = 'kicking'
            if event.key == pygame.K_LSHIFT and szstate != 'walking':
                szstate = 'blocking'            
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                xchange = 0
                scorpionstate = 'ready'
            if event.key == pygame.K_RCTRL:
                scorpionstate = 'ready'
                haspunched = False
                punchsoundplaying = True
            if event.key == pygame.K_m:
                scorpionstate = 'ready'
                hasthrown = False
                spearthrown = False
                spearx = scorpionx
                spearxchange = 0
                if spearbarlength == spearbarmaxlength:
                    spearbarlength = 0
                    spearbarx = int(1060/screenratio)
            if event.key == pygame.K_z:
                szstate = 'ready'
                hasshot = False
                iceshot = False
                icex = subzerox
                icexchange = 0
                currentstateice = 0
                if freezebarlength == freezebarmaxlength:
                    freezebarlength = 0
            if event.key == pygame.K_RSHIFT:
                scorpionstate = 'ready'
                currentstateblocking = 0
            if event.key == pygame.K_a or event.key == pygame.K_d:
                xchangesz = 0
                szstate = 'ready'
            if event.key == pygame.K_LCTRL:
                szstate = 'ready'
                haskickedsz = False
                punchsoundplaying = True
            if event.key == pygame.K_LSHIFT:
                szstate = 'ready'
                currentstateblockingsz = 0      

    scorpiongothit = scorpion.scorpionhit()
    if scorpiongothit is True:
        if scorpionstate == 'ready' or scorpionstate == 'walking':
            if scorpionhealth > 0:
                scorpionhealth -= int(3/screenratio)
        if scorpionstate == 'blocking':
            if scorpionhealth > 0:
                scorpionhealth -= int(1/screenratio)
            else:
                scorpionhealth = 0

    subzerogothit = subzero.subzerohit()
    if subzerogothit is True:
        if szstate == 'ready' or szstate == 'walking':
            if subzerohealth > 0:
                subzerohealth -= int(3/screenratio)
        if szstate == 'blocking':
            if subzerohealth > 0:
                subzerohealth -= int(1/screenratio)
            else:
                subzerohealth = 0 

    scorpionx += xchange   
    scorpiony += ychange

    subzerox += xchangesz   
    subzeroy += ychangesz

    spearx += spearxchange
    icex += icexchange

    if scorpionx < 0:
        scorpionx = 0
    elif scorpionx > int(1000/screenratio):
        scorpionx = int(1000/screenratio)

    if spearx < 0:
        spearx = scorpionx
    elif spearx > int(1000/screenratio):
        spearx = scorpionx

    if icex < 0:
        icex = subzerox
    elif icex > int(1200/screenratio):
        icex = subzerox

    if subzerox < 0:
        subzerox = 0
    elif subzerox > int(1000/screenratio):
        subzerox = int(1000/screenratio)

    if subzerohealth <= 0:
        subzerohaslost = True
        scorpionorientation = 'left'
        scorpionstate = 'ready'
        szorientation = 'right'
        szstate = 'ready'

    if scorpionhealth <= 0:
        scorpionhaslost = True
        scorpionorientation = 'left'
        scorpionstate = 'ready'
        szorientation = 'right'
        szstate = 'ready'

    pygame.display.update()
